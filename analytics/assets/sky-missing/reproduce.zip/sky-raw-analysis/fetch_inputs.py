"""Recreate the included input extract from the two original archives."""
from pathlib import Path
import urllib.request,zipfile,json
import rasterio,shapefile
from rasterio.windows import from_bounds
from shapely.geometry import shape,mapping,box
P=Path(__file__).parent
D=P/'downloads';D.mkdir(exist_ok=True)
urls={'atlas.zip':'https://datapub.gfz-potsdam.de/download/10.5880.GFZ.1.4.2016.001/World_Atlas_2015.zip','boundaries.zip':'https://naciscdn.org/naturalearth/10m/cultural/ne_10m_admin_0_countries_lakes.zip'}
for name,url in urls.items():
 path=D/name
 if not path.exists():urllib.request.urlretrieve(url,path)
 with zipfile.ZipFile(path) as z:z.extractall(D/name.removesuffix('.zip'))
region=box(-12,35,20,61)
names={'Belgium','Netherlands','United Kingdom','Germany','France','Italy','Spain','Switzerland'}
features=[]
for r in shapefile.Reader(str(next((D/'boundaries').glob('*.shp')))).iterShapeRecords():
 name=r.record.as_dict()['ADMIN']
 if name in names:
  g=shape(r.shape.__geo_interface__).intersection(region)
  features.append({'type':'Feature','properties':{'name':name},'geometry':mapping(g)})
(P/'country-boundaries.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features}))
with rasterio.open(D/'atlas/World_Atlas_2015.tif') as ds:
 w=from_bounds(-12,35,20,61,ds.transform).round_offsets().round_lengths();arr=ds.read(1,window=w)
 profile=ds.profile.copy();profile.update(width=arr.shape[1],height=arr.shape[0],transform=ds.window_transform(w),compress='deflate',predictor=3)
 with rasterio.open(P/'europe-atlas-extract.tif','w',**profile) as dst:dst.write(arr,1)
